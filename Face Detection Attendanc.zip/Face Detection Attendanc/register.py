from tkinter import *
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox

class Register:
    def __init__(self,root):
        self.root=root                                                                                          
        self.root.geometry("1270x650+0+0")
        self.root.title("Register Page")
        
        ##self.bg=ImageTk.PhotoImage(file="D:\Face Detection Attendanc\images\bgregister.jpg")
        #bg
        img1=Image.open(r"D:\Face Detection Attendanc\images\back.jpg")
        img1=img1.resize((1270,650),Image.Resampling.LANCZOS)
        self.bg=ImageTk.PhotoImage(img1)
        
        bg_lbl=Label(self.root,image=self.bg)
        bg_lbl.place(x=0,y=0,relwidth=1,relheight=1)
        
        #LEFT
        img=Image.open(r"D:\Face Detection Attendanc\images\registerleft.png")
        img=img.resize((1270,650),Image.Resampling.LANCZOS)
        self.left=ImageTk.PhotoImage(img)
        left_lbl=Label(self.root,image=self.left)
        left_lbl.place(x=100,y=80,width=370,height=530)
        
        #frame
        frame=Frame(self.root,bg="white")
        frame.place(x=470,y=80,width=700,height=530)
        
        register_lbl=Label(frame,text="REGISTER HERE", font=("times new roman",20,"bold"),fg="darkblue",bg="white")
        register_lbl.place(x=20,y=20)
        
        #label & textfield
        fname=Label(frame,text="First Name", font=("times new roman",15,"bold"),bg="white")
        fname.place(x=50,y=70)
        fname_entry=ttk.Entry(frame,font=("times new roman",15))
        fname_entry.place(x=50,y=100,width=250)
        
        lname=Label(frame,text="Last Name", font=("times new roman",15,"bold"),bg="white",fg="black")
        lname.place(x=350,y=70)
        self.txt_lname=ttk.Entry(frame,font=("times new roman",15))
        self.txt_lname.place(x=350,y=100,width=250)
        
        contact=Label(frame,text="Contact No", font=("times new roman",15,"bold"),bg="white")
        contact.place(x=50,y=140)
        self.txt_contact=ttk.Entry(frame,font=("times new roman",15))
        self.txt_contact.place(x=50,y=170,width=250)
        
        email=Label(frame,text="Email", font=("times new roman",15,"bold"),bg="white",fg="black")
        email.place(x=350,y=140)
        self.txt_email=ttk.Entry(frame,font=("times new roman",15))
        self.txt_email.place(x=350,y=170,width=250)
        
        seqque=Label(frame,text="Select Security Question", font=("times new roman",15,"bold"),bg="white")
        seqque.place(x=50,y=210)
        self.combo_seqque=ttk.Combobox(frame,font=("times new roman",15),state="readonly")
        self.combo_seqque["values"]=("Select","Your Birth Place","Your Pet Name")
        self.combo_seqque.place(x=50,y=240,width=250)
        self.combo_seqque.current(0)
        
        seqans=Label(frame,text="Security Answer", font=("times new roman",15,"bold"),bg="white",fg="black")
        seqans.place(x=350,y=210)
        self.txt_seqans=ttk.Entry(frame,font=("times new roman",15))
        self.txt_seqans.place(x=350,y=240,width=250)
        
        pass1=Label(frame,text="Password", font=("times new roman",15,"bold"),bg="white")
        pass1.place(x=50,y=280)
        self.txt_pass1=ttk.Entry(frame,font=("times new roman",15))
        self.txt_pass1.place(x=50,y=310,width=250)
        
        cpass=Label(frame,text="Confirm Password", font=("times new roman",15,"bold"),bg="white")
        cpass.place(x=350,y=280)
        self.txt_cpass=ttk.Entry(frame,font=("times new roman",15))
        self.txt_cpass.place(x=350,y=310,width=250)
        
        #checkbox
        checkbtn=Checkbutton(frame,text="I Agree The Terms & Condition",font=("times new roman",12,"bold"),bg="white",onvalue=1,offvalue=0)
        checkbtn.place(x=50,y=370)
        
        #buttton
        btn1=Button(frame,text="Register Now",cursor="hand2",font=("times new roman",15,"bold"),bg="lightgreen",fg="black")
        btn1.place(x=50,y=420,width=200)
        
        btn2=Button(frame,text="Login Now",cursor="hand2",font=("times new roman",15,"bold"),bg="red",fg="black")
        btn2.place(x=350,y=420,width=200)
        
        
if __name__=="__main__":
    root=Tk()
    app=Register(root)
    root.mainloop()