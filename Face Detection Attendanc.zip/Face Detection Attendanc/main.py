from tkinter import *
from tkinter import ttk
from PIL import Image,ImageTk
from student import Student

class Face_Detection_System:
    def __init__(self,root):
        self.root=root                                                                                          
        self.root.geometry("1270x610+0+0")
        self.root.title("Face Detection System")
        
        ##back image
        img3=Image.open(r"D:\Face Detection Attendanc\images\back.jpg")
        img3=img3.resize((1270,610),Image.Resampling.LANCZOS)
        self.photoimg3=ImageTk.PhotoImage(img3)
        bg_img=Label(self.root,image=self.photoimg3)
        bg_img.place(x=0,y=0,width=1270,height=610)
        
        title_lbl=Label(bg_img,text="FACE DTECTION ATTENDANCE SYSTEM",font=("times new roman",30,"bold"),bg="white",fg="red")
        title_lbl.place(x=150,y=50,width=950,height=40)
        
        #student button
        img4=Image.open(r"D:\Face Detection Attendanc\images\studentdetails.jpg")
        img4=img4.resize((180,180),Image.Resampling.LANCZOS)
        self.photoimg4=ImageTk.PhotoImage(img4)
        
        b1=Button(bg_img,image=self.photoimg4,command=self.student_details,cursor="hand2")
        b1.place(x=150,y=120,width=200,height=180)
        
        b1_1=Button(bg_img,text="Student Details",command=self.student_details,cursor="hand2",font=("times new roman",15,"bold"),bg="darkblue",fg="white")
        b1_1.place(x=150,y=300,width=200,height=30)
        
        #detect face button
        img5=Image.open(r"D:\Face Detection Attendanc\images\facedetect.png")
        img5=img5.resize((180,180),Image.Resampling.LANCZOS)
        self.photoimg5=ImageTk.PhotoImage(img5)
        
        b2=Button(bg_img,image=self.photoimg5)
        b2.place(x=400,y=120,width=200,height=180)
        
        b2_2=Button(bg_img,text="Face Detector",cursor="hand2",font=("times new roman",15,"bold"),bg="darkblue",fg="white")
        b2_2.place(x=400,y=300,width=200,height=30)
        
        #Attendance button
        img6=Image.open(r"D:\Face Detection Attendanc\images\attendence.png")
        img6=img6.resize((180,180),Image.Resampling.LANCZOS)
        self.photoimg6=ImageTk.PhotoImage(img6)
        
        b3=Button(bg_img,image=self.photoimg6)
        b3.place(x=650,y=120,width=200,height=180)
        
        b3_3=Button(bg_img,text="Attendance",cursor="hand2",font=("times new roman",15,"bold"),bg="darkblue",fg="white")
        b3_3.place(x=650,y=300,width=200,height=30) 
        
        #help button
        img7=Image.open(r"D:\Face Detection Attendanc\images\help.jpg")
        img7=img7.resize((180,180),Image.Resampling.LANCZOS)
        self.photoimg7=ImageTk.PhotoImage(img7)
        
        b4=Button(bg_img,image=self.photoimg7)
        b4.place(x=900,y=120,width=200,height=180)
        
        b4_4=Button(bg_img,text="Help Desk",cursor="hand2",font=("times new roman",15,"bold"),bg="darkblue",fg="white")
        b4_4.place(x=900,y=300,width=200,height=30)
        
        #train face button
        img8=Image.open(r"D:\Face Detection Attendanc\images\traindata.jpg")
        img8=img8.resize((180,180),Image.Resampling.LANCZOS)
        self.photoimg8=ImageTk.PhotoImage(img8)
        
        b5=Button(bg_img,image=self.photoimg8)
        b5.place(x=150,y=340,width=200,height=180)
        
        b5_5=Button(bg_img,text="Train Data",cursor="hand2",font=("times new roman",15,"bold"),bg="darkblue",fg="white")
        b5_5.place(x=150,y=520,width=200,height=30)
        
        #photos face button
        img9=Image.open(r"D:\Face Detection Attendanc\images\photos.png")
        img9=img9.resize((180,180),Image.Resampling.LANCZOS)
        self.photoimg9=ImageTk.PhotoImage(img9)
        
        b6=Button(bg_img,image=self.photoimg9)
        b6.place(x=400,y=340,width=200,height=180)
        
        b6_6=Button(bg_img,text="Photos",cursor="hand2",font=("times new roman",15,"bold"),bg="darkblue",fg="white")
        b6_6.place(x=400,y=520,width=200,height=30)
        
        #developer button
        img10=Image.open(r"D:\Face Detection Attendanc\images\developeer.png")
        img10=img10.resize((180,180),Image.Resampling.LANCZOS)
        self.photoimg10=ImageTk.PhotoImage(img10)
        
        b7=Button(bg_img,image=self.photoimg10)
        b7.place(x=650,y=340,width=200,height=180)
        
        b7_7=Button(bg_img,text="Developer",cursor="hand2",font=("times new roman",15,"bold"),bg="darkblue",fg="white")
        b7_7.place(x=650,y=520,width=200,height=30)
        
        #Exit button
        img11=Image.open(r"D:\Face Detection Attendanc\images\exit.jpg")
        img11=img11.resize((180,180),Image.Resampling.LANCZOS)
        self.photoimg11=ImageTk.PhotoImage(img11)
        
        b8=Button(bg_img,image=self.photoimg11)
        b8.place(x=900,y=340,width=200,height=180)
        
        b8_8=Button(bg_img,text="Exit",cursor="hand2",font=("times new roman",15,"bold"),bg="darkblue",fg="white")
        b8_8.place(x=900,y=520,width=200,height=30)
        
        #Rdirect to student details page *student.py*
    def student_details(self):
       self.new_window=Toplevel(self.root)
       self.app=Student(self.new_window)
             
             
             
             
if __name__=="__main__":
    root=Tk()
    obj=Face_Detection_System(root)
    root.mainloop()