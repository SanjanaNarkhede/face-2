from tkinter import *
from tkinter import ttk
from PIL import Image,ImageTk
from main import Face_Detection_System

class Register:
    def __init__(self,root):
        self.root=root                                                                                          
        self.root.geometry("1270x650+0+0")
        self.root.title("Login Page")
    
        img1=Image.open(r"D:\Face Detection Attendanc\images\loginbg.jpeg")
        img1=img1.resize((1270,650),Image.Resampling.LANCZOS)
        self.bg=ImageTk.PhotoImage(img1)
        
        bg_lbl=Label(self.root,image=self.bg)
        bg_lbl.place(x=0,y=0,relwidth=1,relheight=1)
        
        frame=Frame(self.root,bg="lightgreen")
        frame.place(x=420,y=90,width=380,height=450)
        
        logo=Image.open(r"D:\Face Detection Attendanc\images\userloginlogo.png")
        logo=logo.resize((100,100),Image.Resampling.LANCZOS)
        self.photoimg=ImageTk.PhotoImage(logo)
        lblimg1=Label(image=self.photoimg,borderwidth=0)
        lblimg1.place(x=580,y=100,width=70,height=70)
        
        login_lbl=Label(frame,text="Get Started...", font=("times new roman",20,"bold"),fg="purple",bg="lightgreen")
        login_lbl.place(x=120,y=80)
        
        #label & textfield
        uname=Label(frame,text="Username", font=("times new roman",15,"bold"),fg="black",bg="lightgreen")
        uname.place(x=160,y=130)
        uname_entry=ttk.Entry(frame,font=("times new roman",15))
        uname_entry.place(x=70,y=160,width=250)
        
        passwd=Label(frame,text="Password", font=("times new roman",15,"bold"),fg="black",bg="lightgreen")
        passwd.place(x=160,y=220)
        passwd_entry=ttk.Entry(frame,font=("times new roman",15))
        passwd_entry.place(x=70,y=250,width=250)
        
        btn2=Button(frame,text="Login",cursor="hand2",font=("times new roman",15,"bold"),bg="pink",fg="black")
        btn2.place(x=150,y=300,width=80,height=30)
        
        lbl1=Label(frame,text="New User Register", font=("times new roman",12,"bold"),fg="black",bg="lightgreen")
        lbl1.place(x=80,y=350)
        
        lbl2=Label(frame,text="Forgot Password", font=("times new roman",12,"bold"),fg="black",bg="lightgreen")
        lbl2.place(x=80,y=380)
        
        #icon
        user=Image.open(r"D:\Face Detection Attendanc\images\user1.jpg")
        user=user.resize((25,25),Image.Resampling.LANCZOS)
        self.photoimg1=ImageTk.PhotoImage(user)
        user1=Label(frame,image=self.photoimg1,borderwidth=0)
        user1.place(x=130,y=130,width=25,height=25)
        
        pass1=Image.open(r"D:\Face Detection Attendanc\images\passlogo.jpg")
        pass1=user.resize((25,25),Image.Resampling.LANCZOS)
        self.photoimg2=ImageTk.PhotoImage(pass1)
        user2=Label(frame,image=self.photoimg2,borderwidth=0)
        user2.place(x=130,y=220,width=25,height=25)

    def login_to_main(self):
       self.new_window=Toplevel(self.root)
       self.app=Face_Detection_System(self.new_window)
        
        
        
        
        
        

        
        
if __name__=="__main__":
    root=Tk()
    app=Register(root)
    root.mainloop()