from tkinter import *
from tkinter import ttk
from tkinter import messagebox
from PIL import Image,ImageTk
import mysql.connector

class Student:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1270x650+0+0")
        self.root.title("Face Detection System")
        
        #variables
        self.dep=StringVar()
        self.course=StringVar()
        self.dep=StringVar()
        self.year=StringVar()
        self.sem=StringVar()
        self.id=StringVar()
        self.name=StringVar()
        self.div=StringVar()
        self.roll=StringVar()
        self.gender=StringVar()
        self.dob=StringVar()
        self.email=StringVar()
        self.phone=StringVar()
        self.address=StringVar()
        self.teacher=StringVar()
        
        #bg
        img=Image.open(r"D:\Face Detection Attendanc\images\bg.jpg")
        img=img.resize((1270,640),Image.Resampling.LANCZOS)
        self.photo1=ImageTk.PhotoImage(img)
            
        bg_img=Label(self.root,image=self.photo1)
        bg_img.place(x=0,y=0,width=1270,height=660)
            
        title_lbl=Label(bg_img,text="Welcome to Student Panel",font=("times new roman",35,"bold"),bg="white",fg="darkblue")
        title_lbl.place(x=0,y=40,width=1270,height=45)
            
        main_frame=Frame(bg_img,bd=2,bg="white")
        main_frame.place(x=10,y=90,width=1250,height=540)
        
        #left frame
        left_frame=LabelFrame(main_frame,bd=2,bg="white",relief=RIDGE,text="Student Details",font=("times new roman",13,"bold"))
        left_frame.place(x=10,y=10,width=605,height=520)
        
        #current course
        left_frame_course=LabelFrame(left_frame,bd=2,bg="lightgreen",relief=RIDGE,text="Current Course Information",font=("times new roman",13,"bold"))
        left_frame_course.place(x=5,y=3,width=590,height=110)
        
        dep_combo=ttk.Combobox(left_frame_course,textvariable=self.dep,font=("times new roman",12,"bold"),state="read only")
        dep_combo.grid(row=0,column=1)
        dep_combo.place(x=20,y=5,width=250)
        dep_combo["values"]=("Select Department","Computer Science & Engineering","CSE(Data Science)","Artificial Intelligence Machine learning","Entronics and Telecommunication Engineering","Civil","Machanical","Electrical")
        dep_combo.current(0)
        
        course_combo=ttk.Combobox(left_frame_course,textvariable=self.course,font=("times new roman",12,"bold"),state="read only")
        course_combo.grid(row=0,column=2)
        course_combo.place(x=320,y=5, width=250)
        course_combo["values"]=("Select Course","First Year","Second Year","Third Year","B. Tech")
        course_combo.current(0)
        
        year_combo=ttk.Combobox(left_frame_course,textvariable=self.year,font=("times new roman",12,"bold"),state="read only")
        year_combo.grid(row=0,column=1)
        year_combo.place(x=20,y=50,width=250)
        year_combo["values"]=("Select Year","2019-20","2020-21","2021-22","2022-23","2023-24")
        year_combo.current(0)
        
        sem_combo=ttk.Combobox(left_frame_course,textvariable=self.sem,font=("times new roman",12,"bold"),state="read only")
        sem_combo.grid(row=0,column=2)
        sem_combo.place(x=320,y=50, width=250)
        sem_combo["values"]=("Select Semester","First Semester","Second Semester","Third Semester","Fourth Semester","Fifth Semester","Sixth Semester","Seventh Semester","Eighth Semester")
        sem_combo.current(0)
        
        #student inf
        student_frame=LabelFrame(left_frame,bd=2,bg="white",relief=RIDGE,text="Class Student Information",font=("times new roman",13,"bold"))
        student_frame.place(x=5,y=120,width=590,height=370)
        
        #student id
        studentID=Label(student_frame,text="StudentId:", font=("times new roman",12,"bold"),fg="black",bg="white")
        studentID_entry=ttk.Entry(student_frame,textvariable=self.id,width=20,font=("times new roman",12,"bold"))
        studentID.place(x=5,y=10)
        studentID_entry.place(x=100,y=10)
        
        #studentname
        studentname=Label(student_frame,text="Student Name:", font=("times new roman",12,"bold"),fg="black",bg="white")
        studentname_entry=ttk.Entry(student_frame,textvariable=self.name,width=20,font=("times new roman",12,"bold"))
        studentname.place(x=290,y=10)
        studentname_entry.place(x=410,y=10)
        
        #division
        division=Label(student_frame,text="Division:", font=("times new roman",12,"bold"),fg="black",bg="white")
        division.place(x=5,y=50)
        div_combo=ttk.Combobox(student_frame,textvariable=self.div,font=("times new roman",12,"bold"),state="read only")
        div_combo.place(x=100,y=50,width=170)
        div_combo["values"]=("Select Division","A","B","C")
        div_combo.current(0)
        
        #roll NO
        roll=Label(student_frame,text="Roll No:", font=("times new roman",12,"bold"),fg="black",bg="white")
        roll_entry=ttk.Entry(student_frame,textvariable=self.roll,width=20,font=("times new roman",12,"bold"))
        roll.place(x=290,y=50)
        roll_entry.place(x=410,y=50)
        
        
        #gender
        gender=Label(student_frame,text="Gender:", font=("times new roman",12,"bold"),fg="black",bg="white")
        gender.place(x=5,y=90)
        #gender_entry=ttk.Entry(student_frame,textvariable=self.gender,width=20,font=("times new roman",12,"bold"))
        gender_combo=ttk.Combobox(student_frame,textvariable=self.gender,font=("times new roman",12,"bold"),state="read only")
        gender_combo.place(x=100,y=90,width=170)
        gender_combo["values"]=("Male","Female","Other")
        gender_combo.current(0)
        
     
        
        #dob
        dob=Label(student_frame,text="DOB:", font=("times new roman",12,"bold"),fg="black",bg="white")
        dob_entry=ttk.Entry(student_frame,textvariable=self.dob, width=20,font=("times new roman",12,"bold"))
        dob.place(x=290,y=90)
        dob_entry.place(x=410,y=90)
        
        #email
        email=Label(student_frame,text="Email:", font=("times new roman",12,"bold"),fg="black",bg="white")
        email_entry=ttk.Entry(student_frame,textvariable=self.email,width=20,font=("times new roman",12,"bold"))
        email.place(x=5,y=130)
        email_entry.place(x=100,y=130)
        
        #phone
        phone=Label(student_frame,text="Phone No:", font=("times new roman",12,"bold"),fg="black",bg="white")
        phone_entry=ttk.Entry(student_frame,textvariable=self.phone,width=20,font=("times new roman",12,"bold"))
        phone.place(x=290,y=130)
        phone_entry.place(x=410,y=130)
        
        #address
        address=Label(student_frame,text="Address:", font=("times new roman",12,"bold"),fg="black",bg="white")
        address_entry=ttk.Entry(student_frame,textvariable=self.address,width=20,font=("times new roman",12,"bold"))
        address.place(x=5,y=170)
        address_entry.place(x=100,y=170)
        
        #Teacher Name
        Tname=Label(student_frame,text="Teacher Name:", font=("times new roman",12,"bold"),fg="black",bg="white")
        Tname_entry=ttk.Entry(student_frame,textvariable=self.teacher,width=20,font=("times new roman",12,"bold"))
        Tname.place(x=290,y=170)
        Tname_entry.place(x=410,y=170)
        
        #radio
        self.radio1=StringVar()
        radio1=ttk.Radiobutton(student_frame,variable=self.radio1, text="Take Photo Sample",value="Yes")
        radio1.place(x=10,y=220)

        radio2=ttk.Radiobutton(student_frame,variable=self.radio1, text="No Photo Sample",value="No")
        radio2.place(x=150,y=220)
        
        #button
        btn_frame=Frame()
        btn_frame=Frame(left_frame,bd=2,bg="white",relief=RIDGE)
        btn_frame.place(x=5,y=420,width=590,height=70)
        
        save=Button(btn_frame,command=self.add_data,text="Save",font=("times new roman",13,"bold"),bg="green",fg="black")
        save.place(x=10,y=15,width=80)
        
        
        
        update=Button(btn_frame,command=self.update_data ,text="Update",font=("times new roman",13,"bold"),bg="yellow",fg="black")
        update.place(x=100,y=15,width=80)
        
        delete=Button(btn_frame,command=self.delete_data, text="Delete",font=("times new roman",13,"bold"),bg="red",fg="black")
        delete.place(x=190,y=15,width=80)
        
        reset=Button(btn_frame,text="Reset",font=("times new roman",13,"bold"),bg="blue",fg="black")
        reset.place(x=280,y=15,width=80)
        
        takepic=Button(btn_frame,text="Take Pic",font=("times new roman",13,"bold"),bg="pink",fg="black")
        takepic.place(x=370,y=15,width=100)
        
        updatepic=Button(btn_frame,text="Update Pic",font=("times new roman",13,"bold"),bg="purple",fg="black")
        updatepic.place(x=480,y=15,width=100)
        
        
        
        #right frame
        right_frame=LabelFrame(main_frame,bd=2,relief=RIDGE,bg="white", text="Student Details",font=("times new roman",12,"bold"))
        right_frame.place(x=630,y=10,width=600,height=520)
        
        search_right=LabelFrame(right_frame,bd=2,bg="lightgreen",relief=RIDGE,text="Search System",font=("times new roman",13,"bold"))
        search_right.place(x=5,y=3,width=585,height=70)
        
        search=Label(search_right,text="Search By:", font=("times new roman",12,"bold"),fg="black",bg="white")
        search.grid(row=0,column=0,pady=5,padx=10,sticky=W)
        
        course_combo=ttk.Combobox(search_right,width=15, font=("times new roman",12,"bold"),state="read only")
        course_combo.grid(row=0,column=1,padx=2,pady=10,sticky=W)
        course_combo["values"]=("Select","Roll No","Phone No")
        course_combo.current(0)
        
        search_entry=ttk.Entry(search_right,width=12,font=("times new roman",12,"bold"))
        search_entry.grid(row=0,column=2,padx=10,pady=5,sticky=W)
        
        search_btn=Button(search_right,text="Search",width=9,font=("times new roman",13,"bold"),bg="pink",fg="black")
        search_btn.grid(row=0,column=3)
        
        show=Button(search_right,text="Show All",width=9,font=("times new roman",13,"bold"),bg="blue",fg="black")
        show.place(x=480,y=5)
        
        #table
        table_frame=Frame(right_frame,bd=2,bg="white",relief=RIDGE)
        table_frame.place(x=5,y=75,width=585,height=415)
        
        scrollh=ttk.Scrollbar(table_frame,orient=HORIZONTAL)
        scrollv=ttk.Scrollbar(table_frame,orient=VERTICAL)
        self.student_table=ttk.Treeview(table_frame,column=("dep","course","year","sem","id","name","div","roll","gender","dob","email","phone","address","teacher","photo"),xscrollcommand=scrollh.set,yscrollcommand=scrollv.set)
        
        scrollh.pack(side=BOTTOM,fill=X)
        scrollv.pack(side=RIGHT,fill=Y)
        scrollh.config(command=self.student_table.xview)
        scrollv.config(command=self.student_table.yview)
        
        self.student_table.heading("dep",text="Department")
        self.student_table.heading("course",text="Course")
        self.student_table.heading("year",text="Year")
        self.student_table.heading("sem",text="Semester")
        self.student_table.heading("id",text="StudentID")
        self.student_table.heading("name",text="Name")
        self.student_table.heading("div",text="Division")
        self.student_table.heading("roll",text="Roll No")
        self.student_table.heading("gender",text="Gender")
        self.student_table.heading("dob",text="DOB")
        self.student_table.heading("email",text="Email")
        self.student_table.heading("phone",text="Phone ")
        self.student_table.heading("address",text="Address")
        self.student_table.heading("teacher",text="Teacher")
        self.student_table.heading("photo",text="PhotoSampleStatus")
        self.student_table["show"]="headings"
        
        self.student_table.column("dep",width=150)
        self.student_table.column("course",width=100)
        self.student_table.column("year",width=100)
        self.student_table.column("sem",width=100)
        self.student_table.column("id",width=100)
        self.student_table.column("name",width=100)
        self.student_table.column("div",width=100)
        self.student_table.column("roll",width=100)
        self.student_table.column("gender",width=100)
        self.student_table.column("dob",width=100)
        self.student_table.column("email",width=100)
        self.student_table.column("phone",width=100)
        self.student_table.column("address",width=100)
        self.student_table.column("teacher",width=100)
        self.student_table.column("photo",width=150)
        self.student_table.pack(fill=BOTH,expand=1)
        self.student_table.bind("<ButtonRelease>",self.cursor_on)
        self.fetch_data()
    
    #function to save data
    def add_data(self):
        #show error for empty fields
        if self.dep.get()=="select Department" or self.course.get()=="select Course" or self.sem.get()=="select Semester" or self.year.get()=="select Year" or self.name.get()=="" or self.id.get()=="" or self.div.get()=="" or self.roll.get()=="" or self.dob.get()=="" or self.address.get()=="" or self.email.get()=="" or self.gender.get()=="" or self.phone.get()=="" or self.teacher.get()=="":
            messagebox.showerror("Error","All Fields are Required",parent=self.root)
        else:
            try:
                conn=mysql.connector.connect(host="localhost",username="root",password="sanjana@2004",database="Face_Detection_System")
                mycursor=conn.cursor()
                mycursor.execute("insert into student values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(
                    self.dep.get(),self.course.get(),self.year.get(),self.sem.get(),self.id.get(),self.name.get(),
                    self.div.get(),self.roll.get(),self.gender.get(),self.dob.get(),self.email.get(),self.phone.get(),
                    self.address.get(),self.teacher.get(),self.radio1.get()))
                
                conn.commit()
                #function to fetch data
                self.fetch_data()
                conn.close()
                messagebox.showinfo("Success","Students details has been addes successfully",parent="self.root")
            
            except Exception as es:
                messagebox.showerror("Error",f"Due to (str{es})",parent=self.root)
    
    
    #function to fetch data
    def fetch_data(self):
        conn=mysql.connector.connect(host="localhost",username="root",password="sanjana@2004",database="Face_Detection_System")
        mycursor=conn.cursor()
        mycursor.execute("select * from student")
        data=mycursor.fetchall()
        if len(data)!=0:
            self.student_table.delete(*self.student_table.get_children())
            for i in data:
                self.student_table.insert("",END,values=i)
            conn.commit()
        conn.close();   
                            
    ## the values retrieve in textfields for update the data
    def cursor_on(self,event=""):
        update=self.student_table.focus()
        content=self.student_table.item(update)  
        data=content["values"]
        
        self.dep.set(data[0]),  
        self.course.set(data[1]),  
        self.year.set(data[2]),
        self.sem.set(data[3]),
        self.id.set(data[4]),
        self.name.set(data[5]),
        self.div.set(data[6]),
        self.roll.set(data[7]),
        self.gender.set(data[8]),
        self.dob.set(data[9]),
        self.email.set(data[10]),
        self.phone.set(data[11]),
        self.address.set(data[12]),
        self.teacher.set(data[13]),
        self.radio1.set(data[14]),
    
    ##For update function
    def update_data(self):
        #show error for empty fields
        if self.dep.get()=="select Department" or self.course.get()=="select Course" or self.sem.get()=="select Semester" or self.year.get()=="select Year" or self.name.get()=="" or self.id.get()=="" or self.div.get()=="" or self.roll.get()=="" or self.dob.get()=="" or self.address.get()=="" or self.email.get()=="" or self.gender.get()=="" or self.phone.get()=="" or self.teacher.get()=="":
            messagebox.showerror("Error","All Fields are Required",parent=self.root)
        else:
            try:
                update=messagebox.askyesno("Update","Do you want to update this student details",parent=self.root)
                if update>0:
                    conn=mysql.connector.connect(host="localhost",username="root",password="sanjana@2004",database="Face_Detection_System")
                    mycursor=conn.cursor()
                    mycursor.execute("update student set Dep=%s, Course=%s, Year=%s, Semester=%s, Division=%s, Roll=%s, Gender=%s, Dob=%s, Email=%s, Phone=%s, Address=%s, Teacher=%s, PhotoSample=%s where id=%s",(
                        self.dep.get(),self.course.get(),self.year.get(),self.sem.get(),self.name.get(),
                    self.div.get(),self.roll.get(),self.gender.get(),self.dob.get(),self.email.get(),self.phone.get(),
                    self.address.get(),self.teacher.get(),self.radio1.get(),self.id.get()
                    ))
                else:
                    if not update:
                        return
                messagebox.showinfo("Success","Student details successfully update completed",parent=self.root)
                conn.commit()
                self.fetch_data()
                conn.close() 
            except Exception as es:      
                messagebox.showerror("Error",f"Due To: {str(es)}",parent=self.root)
                
    # delete function
    def delete_data(self):
        if self.id.get()=="":
            messagebox.showinfo("Error","Student id must be required",parent=self.root)
        else:
            try:
                delete=messagebox.askyesno("Student Delete Page","Do you want to delete this student details",parent=self.root)
                if delete>0:
                    conn=mysql.connector.connect(host="localhost",username="root",password="sanjana@2004",database="Face_Detection_System")
                    mycursor=conn.cursor()
                    sql="delete from student where id=%s"
                    val=(self.id.get())
                    mycursor.execute(sql,val)
                else:
                    if not delete:
                        return
                conn.commit()
                self.fetch_data()
                conn.close()
                messagebox.showinfo("Delete","Successfully deleted student details",parent=self.root)
                
            except Exception as es:      
                messagebox.showerror("Error",f"Due To: {str(es)}",parent=self.root)
                
                    

        
if __name__=="__main__":
    root=Tk()
    stu=Student(root)
    root.mainloop()
    
